// Trip Moments — add a moment to a trip (Feature F3)
// In-memory only: no backend, no login, no external services.

const moments = [];

const elements = {
  form: document.getElementById("moment-form"),
  memberName: document.getElementById("member-name"),
  photoInput: document.getElementById("photo-input"),
  photoButton: document.getElementById("photo-button"),
  photoName: document.getElementById("photo-name"),
  photoClear: document.getElementById("photo-clear"),
  photoPreview: document.getElementById("photo-preview"),
  note: document.getElementById("note-input"),
  place: document.getElementById("place-input"),
  submitButton: document.getElementById("submit-button"),
  error: document.getElementById("form-error"),
  list: document.getElementById("moments-list"),
  emptyState: document.getElementById("empty-state"),
};

let pendingPhoto = null; // { name, dataUrl }

// --- Rule: can a moment be added? -------------------------------------
// F3-1 + F3-3: a moment needs at least one of a photo, note, or place,
// plus a member name to label it with.
function canAddMoment({ photo, note, place, memberName }) {
  const hasPhoto = Boolean(photo);
  const hasNote = typeof note === "string" && note.trim().length > 0;
  const hasPlace = typeof place === "string" && place.trim().length > 0;
  const hasName = typeof memberName === "string" && memberName.trim().length > 0;

  return hasName && (hasPhoto || hasNote || hasPlace);
}

// --- Save with a simulated failure surface -----------------------------
// F3-2: a review can fail to save; on failure the member is told and the
// photo/note/place stay on screen so they can try again.
function saveMoment(moment) {
  return new Promise((resolve, reject) => {
    try {
      moments.push(moment);
      resolve(moment);
    } catch (err) {
      reject(err);
    }
  });
}

// --- Helpers -----------------------------------------------------------
function showError(message) {
  elements.error.hidden = false;
  elements.error.textContent = message;
}

function clearError() {
  elements.error.hidden = true;
  elements.error.textContent = "";
}

function formatTime(date) {
  return date.toLocaleTimeString(undefined, {
    hour: "numeric",
    minute: "2-digit",
  });
}

function resetPhotoField() {
  pendingPhoto = null;
  elements.photoInput.value = "";
  elements.photoName.textContent = "No photo chosen";
  elements.photoName.hidden = false;
  elements.photoClear.hidden = true;
  elements.photoPreview.hidden = true;
  elements.photoPreview.removeAttribute("src");
}

function keepFormContents() {
  // Intentionally does NOT clear note/place/photo on failure (F3-2).
  elements.memberName.focus();
}

function clearForm() {
  elements.form.reset();
  resetPhotoField();
}

// --- Rendering ---------------------------------------------------------
function renderMoments() {
  elements.list.replaceChildren();

  if (moments.length === 0) {
    elements.emptyState.hidden = false;
    return;
  }
  elements.emptyState.hidden = true;

  for (const moment of moments) {
    elements.list.appendChild(createMomentCard(moment));
  }
}

function createMomentCard(moment) {
  const card = document.createElement("li");
  card.className = "moment-card";

  const header = document.createElement("div");
  header.className = "moment-card__header";

  const author = document.createElement("span");
  author.className = "moment-card__author";
  author.textContent = moment.memberName;

  const time = document.createElement("span");
  time.className = "moment-card__time";
  time.textContent = formatTime(moment.createdAt);

  header.append(author, time);
  card.appendChild(header);

  if (moment.photo) {
    const img = document.createElement("img");
    img.className = "moment-card__photo";
    img.src = moment.photo.dataUrl;
    img.alt = moment.photo.name || "Moment photo";
    card.appendChild(img);
  }

  if (moment.note) {
    const note = document.createElement("p");
    note.className = "moment-card__note";
    note.textContent = moment.note;
    card.appendChild(note);
  }

  if (moment.place) {
    const place = document.createElement("span");
    place.className = "moment-card__place";
    place.textContent = moment.place;
    card.appendChild(place);
  }

  return card;
}

// --- Photo handling ----------------------------------------------------
function handlePhotoSelected(file) {
  clearError();
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    pendingPhoto = { name: file.name, dataUrl: reader.result };
    elements.photoName.textContent = file.name;
    elements.photoClear.hidden = false;
    elements.photoPreview.src = reader.result;
    elements.photoPreview.hidden = false;
  };
  reader.onerror = () => {
    showError("That photo couldn't be read. Please choose another one.");
    resetPhotoField();
  };
  reader.readAsDataURL(file);
}

// --- Submit ------------------------------------------------------------
async function handleSubmit(event) {
  event.preventDefault();
  clearError();

  const memberName = elements.memberName.value;
  const note = elements.note.value;
  const place = elements.place.value;
  const photo = pendingPhoto;

  const draft = { photo, note, place, memberName };

  if (!canAddMoment(draft)) {
    // F3-3: refuse and add nothing.
    const missingName = !memberName.trim();
    const missingContent =
      !photo && !note.trim() && !place.trim();

    if (missingName && missingContent) {
      showError("Add your name and at least a photo, note, or place to share a moment.");
    } else if (missingName) {
      showError("Please add your name so your moment can be labeled.");
    } else if (missingContent) {
      showError("Add at least a photo, note, or place to share a moment.");
    } else {
      showError("Something is missing — please check your moment and try again.");
    }
    return;
  }

  const moment = {
    memberId: memberName.trim(),
    memberName: memberName.trim(),
    photo: photo,
    note: note.trim(),
    place: place.trim(),
    createdAt: new Date(),
  };

  try {
    await saveMoment(moment);
    renderMoments();
    clearForm();
  } catch (err) {
    // F3-2: tell the member and keep the photo/note/place on screen.
    showError("We couldn't save your moment. Your photo, note, and place are still here — please try again.");
    keepFormContents();
  }
}

// --- Wire up -----------------------------------------------------------
function init() {
  elements.form.addEventListener("submit", handleSubmit);

  elements.photoButton.addEventListener("click", () => {
    elements.photoInput.click();
  });

  elements.photoInput.addEventListener("change", (event) => {
    const file = event.target.files && event.target.files[0];
    handlePhotoSelected(file);
  });

  elements.photoClear.addEventListener("click", () => {
    resetPhotoField();
  });

  // Reset the preview if the native input is cleared via cancel dialog.
  elements.photoInput.addEventListener("cancel", () => {
    if (!pendingPhoto) resetPhotoField();
  });

  renderMoments();
}

init();
