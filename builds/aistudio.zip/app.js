/**
 * Trip Moments - Plain JavaScript Single-Page App
 * Implements Feature F3: Add a moment to a trip
 */

// In-memory storage for trip moments
let tripMoments = [];

// Sample image data URIs for instant previewing and testing without local files
const SAMPLE_PHOTOS = {
  sunset: "data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='360' viewBox='0 0 600 360'%3E%3Cdefs%3E%3ClinearGradient id='g1' x1='0%25' y1='0%25' x2='0%25' y2='100%25'%3E%3Cstop offset='0%25' stop-color='%23123552'/%3E%3Cstop offset='60%25' stop-color='%23526578'/%3E%3Cstop offset='100%25' stop-color='%23B8C5D0'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='600' height='360' fill='url(%23g1)'/%3E%3Ccircle cx='300' cy='220' r='55' fill='%23F7F9FB' opacity='0.9'/%3E%3Cpath d='M0 360 L180 230 L320 310 L440 210 L600 360 Z' fill='%23172B40'/%3E%3Ctext x='300' y='335' fill='%23FFFFFF' font-family='Arial, sans-serif' font-size='16' text-anchor='middle'%3ESunset Viewpoint%3C/text%3E%3C/svg%3E",
  cafe: "data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='360' viewBox='0 0 600 360'%3E%3Cdefs%3E%3ClinearGradient id='g2' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' stop-color='%23526578'/%3E%3Cstop offset='100%25' stop-color='%23123552'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='600' height='360' fill='url(%23g2)'/%3E%3Crect x='180' y='140' width='240' height='150' rx='10' fill='%23F7F9FB'/%3E%3Cpath d='M420 170 C460 170 460 230 420 230' fill='none' stroke='%23F7F9FB' stroke-width='16'/%3E%3Ctext x='300' y='325' fill='%23FFFFFF' font-family='Arial, sans-serif' font-size='16' text-anchor='middle'%3ECozy Coffee Stop%3C/text%3E%3C/svg%3E",
  trail: "data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='360' viewBox='0 0 600 360'%3E%3Cdefs%3E%3ClinearGradient id='g3' x1='0%25' y1='0%25' x2='0%25' y2='100%25'%3E%3Cstop offset='0%25' stop-color='%23172B40'/%3E%3Cstop offset='100%25' stop-color='%23526578'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='600' height='360' fill='url(%23g3)'/%3E%3Cpolygon points='120,360 260,150 400,360' fill='%23123552'/%3E%3Cpolygon points='280,360 440,110 600,360' fill='%23172B40' opacity='0.8'/%3E%3Ctext x='300' y='335' fill='%23FFFFFF' font-family='Arial, sans-serif' font-size='16' text-anchor='middle'%3EMountain Trailhead%3C/text%3E%3C/svg%3E"
};

// Current photo in form (can be base64 data URI, URL, or empty string)
let currentPhotoData = "";

// Active filter for timeline view
let activeFilter = "ALL";

/**
 * =========================================================================
 * NAMED RULE FUNCTION (Required by specification)
 * =========================================================================
 * Decides whether a moment can be added to the trip.
 *
 * Rule F3-1 & F3-3:
 * - A moment CAN be added IF AND ONLY IF it has at least one of:
 *   1. A photo (non-empty string)
 *   2. A note (non-empty string after trimming)
 *   3. A place (non-empty string after trimming)
 * - If none of these three are present, returns false.
 *
 * @param {{ photo?: string | null, note?: string | null, place?: string | null }} moment
 * @returns {boolean} True if the moment has at least one of photo, note, or place; false otherwise.
 */
function canAddMoment(moment) {
  if (!moment) {
    return false;
  }

  const hasPhoto = typeof moment.photo === 'string' && moment.photo.trim().length > 0;
  const hasNote = typeof moment.note === 'string' && moment.note.trim().length > 0;
  const hasPlace = typeof moment.place === 'string' && moment.place.trim().length > 0;

  return hasPhoto || hasNote || hasPlace;
}

// Attach to window so automated tests and inspection can access it
window.canAddMoment = canAddMoment;

/**
 * Saves a moment into the trip's in-memory record.
 * Handles storage failure simulation according to rule F3-2.
 *
 * F3-2: IF a review fails to save, THEN the app shall tell the member
 * and keep the photo, note, and location on screen so they can try again.
 *
 * @param {Object} moment
 * @throws {Error} If save fails (simulated or runtime error)
 */
function saveMoment(moment) {
  const simulateCheckbox = document.getElementById('simulate-save-failure');
  const isSimulationForced = Boolean(simulateCheckbox && simulateCheckbox.checked);
  const isGlobalSimulated = Boolean(window.__simulateSaveFailure);

  if (isSimulationForced || isGlobalSimulated) {
    throw new Error('Save error: Unable to save moment to trip.');
  }

  // Prepend new moment to trip
  tripMoments.unshift(moment);
}

// Attach saveMoment to window
window.saveMoment = saveMoment;
window.getTripMoments = () => tripMoments;

/**
 * UI helper: displays an inline error message under the form.
 * Never uses window.alert or modal popups.
 *
 * @param {string} message
 */
function showFormError(message) {
  const errorContainer = document.getElementById('form-error');
  const successContainer = document.getElementById('form-success');

  if (successContainer) {
    successContainer.textContent = '';
    successContainer.classList.add('hidden');
  }

  if (errorContainer) {
    errorContainer.textContent = message;
    errorContainer.classList.remove('hidden');
  }
}

/**
 * UI helper: displays an inline success message under the form.
 *
 * @param {string} message
 */
function showFormSuccess(message) {
  const errorContainer = document.getElementById('form-error');
  const successContainer = document.getElementById('form-success');

  if (errorContainer) {
    errorContainer.textContent = '';
    errorContainer.classList.add('hidden');
  }

  if (successContainer) {
    successContainer.textContent = message;
    successContainer.classList.remove('hidden');
  }
}

/**
 * UI helper: clears all inline messages.
 */
function clearMessages() {
  const errorContainer = document.getElementById('form-error');
  const successContainer = document.getElementById('form-success');

  if (errorContainer) {
    errorContainer.textContent = '';
    errorContainer.classList.add('hidden');
  }
  if (successContainer) {
    successContainer.textContent = '';
    successContainer.classList.add('hidden');
  }
}

/**
 * Updates the photo preview element based on currentPhotoData.
 */
function updatePhotoPreview() {
  const previewWrapper = document.getElementById('photo-preview-wrapper');
  const previewImg = document.getElementById('photo-preview-img');

  if (currentPhotoData && currentPhotoData.trim().length > 0) {
    previewImg.src = currentPhotoData;
    previewWrapper.classList.remove('hidden');
  } else {
    previewImg.src = '';
    previewWrapper.classList.add('hidden');
  }
}

/**
 * Clears form input fields on successful submission.
 */
function resetFormInputs() {
  currentPhotoData = "";
  updatePhotoPreview();

  const fileInput = document.getElementById('moment-photo-file');
  if (fileInput) fileInput.value = '';

  const noteInput = document.getElementById('moment-note');
  if (noteInput) noteInput.value = '';

  const placeInput = document.getElementById('moment-place');
  if (placeInput) placeInput.value = '';
}

/**
 * Gets the currently selected or entered member name.
 *
 * @returns {string} Member name
 */
function getSelectedMemberName() {
  const memberSelect = document.getElementById('member-select');
  const customMemberInput = document.getElementById('custom-member-name');

  if (memberSelect && memberSelect.value === 'CUSTOM') {
    if (customMemberInput && customMemberInput.value.trim().length > 0) {
      return customMemberInput.value.trim();
    }
    return 'Traveler';
  }

  if (memberSelect && memberSelect.value) {
    return memberSelect.value;
  }

  return 'Liam';
}

/**
 * Sets the active member selector in UI.
 *
 * @param {string} memberName
 */
function setActiveMember(memberName) {
  const memberSelect = document.getElementById('member-select');
  const customMemberContainer = document.getElementById('custom-member-group');
  const profile1Btn = document.getElementById('profile-1-btn');
  const profile2Btn = document.getElementById('profile-2-btn');

  if (memberName === 'Liam') {
    if (memberSelect) memberSelect.value = 'Liam';
    if (customMemberContainer) customMemberContainer.classList.add('hidden');
    if (profile1Btn) profile1Btn.classList.add('active');
    if (profile2Btn) profile2Btn.classList.remove('active');
  } else if (memberName === 'Maya') {
    if (memberSelect) memberSelect.value = 'Maya';
    if (customMemberContainer) customMemberContainer.classList.add('hidden');
    if (profile1Btn) profile1Btn.classList.remove('active');
    if (profile2Btn) profile2Btn.classList.add('active');
  } else {
    if (memberSelect) memberSelect.value = 'CUSTOM';
    if (customMemberContainer) customMemberContainer.classList.remove('hidden');
    if (profile1Btn) profile1Btn.classList.remove('active');
    if (profile2Btn) profile2Btn.classList.remove('active');
  }
}

/**
 * Renders the trip moments list in the DOM.
 */
function renderMomentsList() {
  const listContainer = document.getElementById('moments-list');
  const countBadge = document.getElementById('moments-count-badge');

  if (!listContainer) return;

  const filtered = tripMoments.filter(item => {
    if (activeFilter === 'ALL') return true;
    return item.member.toLowerCase() === activeFilter.toLowerCase();
  });

  if (countBadge) {
    countBadge.textContent = `${tripMoments.length} moment${tripMoments.length === 1 ? '' : 's'}`;
  }

  if (filtered.length === 0) {
    listContainer.innerHTML = `
      <div class="empty-state">
        <p>No moments added ${activeFilter === 'ALL' ? 'yet' : `by ${activeFilter}`}.</p>
        <p style="margin-top: 0.5rem; font-size: var(--font-size-min);">Use the form above to add a photo, note, or place to the trip.</p>
      </div>
    `;
    return;
  }

  listContainer.innerHTML = filtered.map(moment => {
    const hasPhoto = Boolean(moment.photo && moment.photo.trim().length > 0);
    const hasNote = Boolean(moment.note && moment.note.trim().length > 0);
    const hasPlace = Boolean(moment.place && moment.place.trim().length > 0);

    return `
      <article class="moment-card" data-id="${moment.id}">
        <div class="moment-card-header">
          <span class="moment-member-tag">Added by ${escapeHtml(moment.member)}</span>
          <span class="moment-time-tag">${escapeHtml(moment.timestamp || 'Today')}</span>
        </div>
        ${hasPhoto ? `<img src="${escapeHtml(moment.photo)}" alt="Trip moment photo by ${escapeHtml(moment.member)}" class="moment-photo-display" />` : ''}
        ${hasNote ? `<p class="moment-note-text">${escapeHtml(moment.note)}</p>` : ''}
        ${hasPlace ? `
          <div>
            <span class="moment-place-tag">
              <span>📍</span>
              <strong>${escapeHtml(moment.place)}</strong>
            </span>
          </div>
        ` : ''}
      </article>
    `;
  }).join('');
}

/**
 * Escapes HTML characters for safe DOM rendering.
 *
 * @param {string} str
 * @returns {string}
 */
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Initialize event listeners and starter state when DOM is loaded.
 */
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('add-moment-form');
  const fileInput = document.getElementById('moment-photo-file');
  const removePhotoBtn = document.getElementById('remove-photo-btn');
  const memberSelect = document.getElementById('member-select');
  const customMemberContainer = document.getElementById('custom-member-group');
  const profile1Btn = document.getElementById('profile-1-btn');
  const profile2Btn = document.getElementById('profile-2-btn');
  const filterAllBtn = document.getElementById('filter-all-btn');
  const filterLiamBtn = document.getElementById('filter-liam-btn');
  const filterMayaBtn = document.getElementById('filter-maya-btn');

  // Sample photo click handlers
  const sampleSunsetBtn = document.getElementById('sample-photo-sunset');
  const sampleCafeBtn = document.getElementById('sample-photo-cafe');
  const sampleTrailBtn = document.getElementById('sample-photo-trail');

  if (sampleSunsetBtn) {
    sampleSunsetBtn.addEventListener('click', () => {
      currentPhotoData = SAMPLE_PHOTOS.sunset;
      updatePhotoPreview();
    });
  }

  if (sampleCafeBtn) {
    sampleCafeBtn.addEventListener('click', () => {
      currentPhotoData = SAMPLE_PHOTOS.cafe;
      updatePhotoPreview();
    });
  }

  if (sampleTrailBtn) {
    sampleTrailBtn.addEventListener('click', () => {
      currentPhotoData = SAMPLE_PHOTOS.trail;
      updatePhotoPreview();
    });
  }

  // Profile presets
  if (profile1Btn) {
    profile1Btn.addEventListener('click', () => {
      setActiveMember('Liam');
    });
  }

  if (profile2Btn) {
    profile2Btn.addEventListener('click', () => {
      setActiveMember('Maya');
    });
  }

  if (memberSelect) {
    memberSelect.addEventListener('change', (e) => {
      setActiveMember(e.target.value);
    });
  }

  // File upload handling
  if (fileInput) {
    fileInput.addEventListener('change', (e) => {
      const file = e.target.files && e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          currentPhotoData = event.target ? event.target.result : "";
          updatePhotoPreview();
        };
        reader.readAsDataURL(file);
      }
    });
  }

  // Remove photo button
  if (removePhotoBtn) {
    removePhotoBtn.addEventListener('click', () => {
      currentPhotoData = "";
      if (fileInput) fileInput.value = '';
      updatePhotoPreview();
    });
  }

  // Filter buttons
  function updateFilterButtons() {
    [filterAllBtn, filterLiamBtn, filterMayaBtn].forEach(btn => {
      if (btn) btn.classList.remove('active');
    });
    if (activeFilter === 'ALL' && filterAllBtn) filterAllBtn.classList.add('active');
    if (activeFilter === 'LIAM' && filterLiamBtn) filterLiamBtn.classList.add('active');
    if (activeFilter === 'MAYA' && filterMayaBtn) filterMayaBtn.classList.add('active');
  }

  if (filterAllBtn) {
    filterAllBtn.addEventListener('click', () => {
      activeFilter = 'ALL';
      updateFilterButtons();
      renderMomentsList();
    });
  }
  if (filterLiamBtn) {
    filterLiamBtn.addEventListener('click', () => {
      activeFilter = 'LIAM';
      updateFilterButtons();
      renderMomentsList();
    });
  }
  if (filterMayaBtn) {
    filterMayaBtn.addEventListener('click', () => {
      activeFilter = 'MAYA';
      updateFilterButtons();
      renderMomentsList();
    });
  }

  // Form Submission
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      clearMessages();

      const member = getSelectedMemberName();
      const noteInput = document.getElementById('moment-note');
      const placeInput = document.getElementById('moment-place');

      const note = noteInput ? noteInput.value.trim() : '';
      const place = placeInput ? placeInput.value.trim() : '';
      const photo = currentPhotoData;

      const candidateMoment = {
        id: 'moment-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
        member: member,
        photo: photo,
        note: note,
        place: place,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      /**
       * F3-3. IF a member submits a moment with no photo, note, or place,
       * THEN the app shall refuse and add nothing.
       */
      if (!canAddMoment(candidateMoment)) {
        showFormError('Cannot add moment: please provide at least one photo, note, or place.');
        return;
      }

      /**
       * F3-1. WHEN a member submits a moment with at least one of a photo, note, or place,
       * the app shall add it to the trip, labeled with the member's name.
       *
       * F3-2. IF a review fails to save, THEN the app shall tell the member
       * and keep the photo, note, and location on screen so they can try again.
       */
      try {
        saveMoment(candidateMoment);

        // Saved successfully: reset inputs and update list
        resetFormInputs();
        showFormSuccess(`Moment added to trip for ${candidateMoment.member}!`);
        renderMomentsList();
      } catch (saveError) {
        // F3-2: Notice that resetFormInputs() is NOT called!
        // Photo preview, currentPhotoData, noteInput.value, and placeInput.value
        // are strictly kept on screen so the member can retry without losing their work.
        showFormError('Failed to save moment. Your photo, note, and location have been kept on screen so you can try again.');
      }
    });
  }

  // Initial starter moments from Profile 1 and Profile 2
  tripMoments = [
    {
      id: 'initial-1',
      member: 'Liam',
      photo: '',
      note: 'Grabbed warm cinnamon cardamom buns straight out of the brick oven. Hands down the best pit stop so far!',
      place: 'Highland Bakehouse, Pitlochry',
      timestamp: '10:15 AM'
    },
    {
      id: 'initial-2',
      member: 'Maya',
      photo: SAMPLE_PHOTOS.sunset,
      note: 'First light breaking over the ridge at 6:45 AM. Completely quiet before the tour buses arrive.',
      place: 'Quiraing Ridge, Isle of Skye',
      timestamp: '07:05 AM'
    }
  ];

  updateFilterButtons();
  renderMomentsList();
});
